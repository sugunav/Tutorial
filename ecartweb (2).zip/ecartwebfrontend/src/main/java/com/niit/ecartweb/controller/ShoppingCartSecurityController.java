/*package com.niit.ecartweb.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ShoppingCartSecurityController {
	
	Authentication auth=SecurityContextHolder.getContext().getAuthentication();
	
	@RequestMapping(value={"/","/index"},method=RequestMethod.GET)
	public String homePage(ModelMap model){
		model.addAttribute("user", auth.getPrincipal());
		return "welcome";
	}
	
	@RequestMapping(value="/admin",method=RequestMethod.GET)
	public String adminPage(ModelMap model){
		model.addAttribute("user",auth.getPrincipal());
		return "admin";
	}
	
	@RequestMapping(value="/super_admin",method=RequestMethod.GET)
	public String superAdminPage(ModelMap model){
		model.addAttribute("user",auth.getPrincipal());
		return "super_admin";
	}
	
	@RequestMapping(value="/Access_Denied",method=RequestMethod.GET)
	public String accessDeniedPage(ModelMap model){
		model.addAttribute("user", auth.getPrincipal());
		return "accessDenied";
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String loginPage(){
		return "login";
	}

}*/
