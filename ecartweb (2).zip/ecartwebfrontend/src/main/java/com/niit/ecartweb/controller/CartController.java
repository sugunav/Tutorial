package com.niit.ecartweb.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.ecartweb.dao.CartDAO;
import com.niit.ecartweb.dao.CategoryDAO;
import com.niit.ecartweb.dao.ProductDAO;
import com.niit.ecartweb.model.Cart;
import com.niit.ecartweb.model.Product;

@Controller
public class CartController {
	
	@Autowired
	Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private ProductDAO productDAO;
	
	
	
	@RequestMapping(value="/myCart", method=RequestMethod.GET)
	public String myCart(Model model,HttpSession session){
		model.addAttribute("cart", cart);
		
		//get logged in user id
		String loggedInUserid=(String) session.getAttribute("loggedInUserID");
		System.out.println(loggedInUserid);
		
		//get Cart details based on logged in user attribute
		model.addAttribute("cartList", cartDAO.list(loggedInUserid));
		//model.addAttribute("cartList", cartDAO.getCart(loggedInUserid));
		model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid));
		model.addAttribute("displayCart", "true");
		return "cart";
	}
	
	@RequestMapping(value= "/cart/add/{id}", method = RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id){
		
	
	 Product product =	 productDAO.getProduct(id);
	 Cart cart = new Cart();
	 //cart.setId(4);
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 cart.setQuantity(1);
	 cart.setUserID("U002");  //  id should keep session and use the same id
	 cart.setStatus("N");  // 
		cartDAO.saveOrUpdate(cart);
		//return "redirect:/views/home.jsp";
		return "redirect:/onLoad";
		
		
	}
	@RequestMapping("cart/delete/{id}")
    public String removeCart(@PathVariable("id") int id,ModelMap model) throws Exception{
		
       try {
		cartDAO.delete(id);
		model.addAttribute("message","Successfully removed");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/myCart";
    }
 
 

}
