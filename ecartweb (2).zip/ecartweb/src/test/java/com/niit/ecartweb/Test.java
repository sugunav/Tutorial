package com.niit.ecartweb;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;




import com.niit.ecartweb.dao.CategoryDAO;
import com.niit.ecartweb.model.Category;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		CategoryDAO categoryDAO=(CategoryDAO) context.getBean("categoryDAO"); //Getting categorydao object
		System.out.println("success");
		
		Category category=(Category) context.getBean("category");  //Getting cateogry object
		System.out.println("SUCCESS");
		
		category.setId("CAT002");
		category.setName("CNAME002");
		category.setDescription("CDESC002");
		
		//categoryDAO.saveOrUpdate(category);
		
		//categoryDAO.delete("CAT002");
		
		System.out.println(categoryDAO.getCategory("CAT002").getName());
	
	}

}
