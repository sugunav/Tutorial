package com.niit.ecartweb.dao;

import java.util.List;

import com.niit.ecartweb.model.Category;

public interface CategoryDAO {

	public Category getCategory(String id);
	public void saveOrUpdate(Category category);
	public void delete(String id);
	public List<Category> list() ;
	public Category getByName(String name);
	
}
