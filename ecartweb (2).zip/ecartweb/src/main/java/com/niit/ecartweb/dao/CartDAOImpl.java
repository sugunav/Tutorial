package com.niit.ecartweb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.ecartweb.model.Cart;


@Repository("cartDAO")
public class CartDAOImpl implements CartDAO {
	
	@Autowired
	private Cart cart;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public CartDAOImpl(SessionFactory sessionFactory){   //Constructor
		this.sessionFactory=sessionFactory;
	}
	@Transactional
	public void saveOrUpdate(Cart cart){            //save or update
		sessionFactory.getCurrentSession().saveOrUpdate(cart);
	}
	
	@Transactional
	public String delete(int id){
		cart.setId(id);
		try {
			sessionFactory.getCurrentSession().delete(cart);
			
		} catch (HibernateException e) {
			e.printStackTrace();
			return e.getMessage();
			// TODO: handle exception
		}
		return null;
		
	}
	
	@Transactional
	public Cart getCart(String id){
		String hql="from Cart where userID="+"'"+id+"'"+"and status='"+"N'";
		Query query=(Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> listCart= (List<Cart>)query.getResultList();
		
		if(listCart!=null &&!(listCart.isEmpty()))
		{
			return listCart.get(0);
		}else{
			
		return null;
		
		}
		
	}
	
	@Transactional
	public List<Cart> list(String id) {
		String hql="from Cart where userID="+"'"+id+"'"+"and status='"+"N'";
		Query query=(Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> listCart=query.list();
	
		/*@SuppressWarnings("unchecked")
		List<Cart> listCart = (List<Cart>) sessionFactory
				.getCurrentSession().createCriteria(Cart.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();*/

		return listCart;
	}
	
	/*@Transactional
	public List<Cart> list() {
		/*String hql="from Cart where userID="+"'"+id+"'"+"and status='"+"N'";
		Query query=(Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> listCart=query.list();*/
	
	/*	@SuppressWarnings("unchecked")
		List<Cart> listCart = (List<Cart>) sessionFactory
				.getCurrentSession().createCriteria(Cart.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return listCart;
	}
	
/*	@Transactional
	public int getTotalAmount(String id){
		String hql="select sum(price) from Cart where userID='"+id+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		int sum= (Integer) query.uniqueResult();
		return sum;
	}*/
	

	@Transactional
	public long getTotalAmount(String id) {
		String hql = "select sum(price) from Cart where userID = " + "'" + id + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		/*query.executeUpdate();
		return query.getFirstResult();*/   // Need to check
		long sum= (Long) query.uniqueResult();
		return sum;

	}

}
