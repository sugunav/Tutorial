package com.niit.ecartweb.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.Supplier;
import com.niit.ecartweb.model.Supplier;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public SupplierDAOImpl(SessionFactory sessionFactory){   //Constructor
		this.sessionFactory=sessionFactory;
	}
	
	@Transactional
	public void saveOrUpdate(Supplier supplier){            //save or update
		sessionFactory.getCurrentSession().saveOrUpdate(supplier);
	}
	
	@Transactional
	public void delete(String id){
		Supplier supplierToDelete=new Supplier();
		supplierToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(supplierToDelete);
	}
	
	@Transactional
	public Supplier getSupplier(String id){
		String hql="from Supplier where id="+"'"+id+"'";
		Query query=(Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Supplier> listSupplier= (List<Supplier>)query.getResultList();
		
		if(listSupplier!=null &&!(listSupplier.isEmpty()))
		{
			return listSupplier.get(0);
		}
		return null;
		
		
		
	}
	
	@Transactional
	public List<Supplier> list() {
		@SuppressWarnings("unchecked")
		List<Supplier> listSupplier = (List<Supplier>) sessionFactory
				.getCurrentSession().createCriteria(Supplier.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listSupplier;
	}
	
	
	@Transactional
	public Supplier getByName(String name){
		String hql="from Supplier where name='"+name+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Supplier> listSupplier=query.list();
		
		if(!listSupplier.isEmpty()||listSupplier!=null){
			return listSupplier.get(0);
		}
		else{
			return null;
		}
	}

	

}
