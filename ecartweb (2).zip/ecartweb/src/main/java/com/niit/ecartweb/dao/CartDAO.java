package com.niit.ecartweb.dao;

import java.util.List;

import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.Cart;

public interface CartDAO {

	public Cart getCart(String id);
	public void saveOrUpdate(Cart cart);
	public String delete(int id);
	public List<Cart> list(String id) ;
	public long getTotalAmount(String id);
	//public List<Cart> list();
	
}
