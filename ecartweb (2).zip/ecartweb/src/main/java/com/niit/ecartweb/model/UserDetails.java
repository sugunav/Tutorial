/*package com.niit.ecartweb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="user")

public class UserDetails {
	@Id
private String id;
private String name;
private String password;
private String email;
private int mob_no;

@Column (name="admin",columnDefinition="tinyinit default 0")
private byte admin;

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getMail() {
	return email;
}

public void setMail(String mail) {
	this.email = email;
}

public int getMob_no() {
	return mob_no;
}

public void setMob_no(int mob_no) {
	this.mob_no = mob_no;
}

public byte getAdmin() {
	return admin;
}

public void setAdmin(byte admin) {
	this.admin = admin;
}



}*/
