package com.niit.ecartweb;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.UserDAO;
import com.niit.ecartweb.model.User;

public class UserTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		UserDAO userDAO=(UserDAO) context.getBean("userDAO");
		//System.out.println("success");
		
		User user=(User) context.getBean("user");
		
		user.setId("USER001");
		user.setName("NIIT");
		user.setPassword("NIIT");
		user.setAddress("ADDRESS001");
		user.setMob_no("MOB001");
		user.setMail("MAIL001");
		
		
		//userDAO.saveOrUpdate(user);
		
		//System.out.println(userDAO.getUser("USER001").getName());

	}

}
