package com.niit.ecartweb;

import javax.security.auth.login.AppConfigurationEntry;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.SupplierDAO;
import com.niit.ecartweb.model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		SupplierDAO supplierDAO =(SupplierDAO) context.getBean("supplierDAO");
		//System.out.println("success");
		
		Supplier supplier=(Supplier) context.getBean("supplier");
		//System.out.println("SUCCESS");
		
		supplier.setId("SUP001");
		supplier.setName("SNAME001");
		supplier.setAddress("SUPADDRESS001");
		supplier.setMob_no(0000);
		
		//supplierDAO.saveOrUpdate(supplier);
		
		//supplierDAO.delete("S004");
		
		System.out.println(supplierDAO.getSupplier("S001").getName());
		
		
	}

}
