package com.niit.ecartweb;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ecartweb.dao.ProductDAO;
import com.niit.ecartweb.dao.SupplierDAO;
import com.niit.ecartweb.model.Product;
import com.niit.ecartweb.model.Supplier;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.ecartweb");
		context.refresh();
		
		ProductDAO productDAO =(ProductDAO) context.getBean("productDAO");
		//System.out.println("success");
		
		Product product=(Product) context.getBean("product");
		//System.out.println("SUCCESS");
		
		product.setId("PRD002");
		product.setName("PNAME002");
		product.setDescription("PRD_DESC002");
		product.setPrice(600);
		product.setCategory_id("CAT002");
		product.setSupplier_id("S001");
		
		productDAO.saveOrUpdate(product);
		
		//productDAO.delete("PRD003");
		
		//System.out.println(productDAO.getProduct("PRD002").getName());
		

	}

}
