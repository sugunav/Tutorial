package com.niit.ecartweb.dao;

import java.util.List;

import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.Cart;

public interface CartDAO {

	public Cart getCart(String id);
	public void saveOrUpdate(Cart cart);
	public String delete(String id);
	public List<Cart> list(String id) ;
	public int getTotalAmount(String id);
	
}
