package com.niit.ecartweb.dao;

import java.util.List;






import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.ecartweb.model.Category;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	
	Logger logger=LoggerFactory.getLogger(CategoryDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public CategoryDAOImpl(SessionFactory sessionFactory) { // Constructor
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(Category category) { // save or update
		logger.debug("Starting of method save or update");
		try{
		sessionFactory.getCurrentSession().saveOrUpdate(category);
		}
		catch(HibernateException e){
			e.printStackTrace();
			logger.error("error occured while saving");
			logger.error(e.getMessage());
		}
		
		logger.debug("ending method saveorupdate");
	}

	@Transactional
	public void delete(String id) {//delete
		logger.debug("starting of delete");
		
		Category categoryToDelete = new Category();
		categoryToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(categoryToDelete);
		
		logger.debug("ending of delete");
	}

	@Transactional
	public Category getCategory(String id) {
		logger.debug("calling get");
		String hql = "from Category where id=" + "'" + id + "'";
		Query query =(Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> listCategory = (List<Category>) query.list();
		logger.debug("end of call get");
		if (listCategory != null && !listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		return null;

	}
@Transactional
	public List<Category> list() {
	logger.debug("callinglist");
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) sessionFactory
				.getCurrentSession().createCriteria(Category.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		logger.debug("end of call list");
		return listCategory;
	}
	@Transactional
	public Category getByName(String name){
		logger.debug("calling get by name");
		String hql="from Category where name='"+name+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Category> listCategory=query.list();
		
		logger.debug("end of call get by name");
		
		if(!listCategory.isEmpty()||listCategory!=null){
			return listCategory.get(0);
		}
		else{
			return null;
		}
	}

}
