package com.niit.ecartweb.dao;

import java.util.List;

import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.Product;

public interface ProductDAO {

	public Product getProduct(String id);
	public void saveOrUpdate(Product product);
	public void delete(String id);
	public List<Product> list() ;
	public Product getByName(String name);
	
}
