package com.niit.ecart;

public class LoginDAO {
	private String user;
	private String password;
	public boolean isValid(String user,String password){
		this.user=user;
		this.password=password;
		if(user.equals(password)){
			return true;
		}
		else{
			return false;
		}
	}

}
