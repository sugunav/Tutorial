package com.niit.ecartweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;










import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ecartweb.dao.CartDAO;
import com.niit.ecartweb.dao.CategoryDAO;
import com.niit.ecartweb.dao.UserDAO;
import com.niit.ecartweb.model.Cart;
import com.niit.ecartweb.model.Category;
import com.niit.ecartweb.model.User;


@Controller
public class UserController {
	@Autowired
	private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	@Autowired
	Category category;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User userDetails;
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session){
		
		ModelAndView mv=new ModelAndView("/index");
		session.setAttribute("category",category);
		session.setAttribute("categoryList", categoryDAO.list());
		return mv;
		
	}


	

	
	@RequestMapping("/Signup")
public ModelAndView signup(){
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("userDetails", userDetails);
		mv.addObject("isUserClickedRegisterHere", "true");
		return mv;
	}
	
	/*@RequestMapping("/check")
	public ModelAndView login(@RequestParam(name="name")String name,@RequestParam(name="password")String password ,HttpSession session){
		ModelAndView mv;
		
		boolean isValidUser=userDAO.isValidUser(name, password);
		
		
		if(isValidUser){
			
			
			userDetails=userDAO.getUser(name);
			session.setAttribute("loggedInUser",userDetails.getName());
			session.setAttribute("loggedInUserID",userDetails.getId());
			
			
			if(userDetails.getAdmin()==1){
				mv=new ModelAndView("/adminHome");
				mv.addObject("message", "welcome admin"+userDetails.getName());
			}
			else{
				mv=new ModelAndView("/index");
				session.setAttribute("category",category);
				session.setAttribute("categoryList", categoryDAO.list());
				mv.addObject("message","welcome"+userDetails.getName());
				cart=cartDAO.getCart(name);	
				mv.addObject("cart", cart);
				List<Cart> cartList=cartDAO.list(name);
				mv.addObject("cartList", cartList);
				mv.addObject("cartSize", cartList.size());
				
			}
		}
		else{
			mv=new ModelAndView("/login");
			mv.addObject("message","Invalid user");
		}
	return mv;
	}*/
	
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView login(@RequestParam(value="error",required=false)String error,@RequestParam(value="logout",required=false)String logout){
		ModelAndView model=new ModelAndView();
		if(error!=null){
			System.out.println("ERROR.....");
			model.addObject("error", "Invalid Credentials");
		}
		if(logout!=null){
			System.out.println("LOGOUT.....");
			model.addObject("msg", "You have logged out successfully");
		}
		model.setViewName("login");
		return model;
	}
	
	@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User userDetails){
		userDAO.saveOrUpdate(userDetails);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("/index");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
	
		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");
	
		return mv;
	 }
	
	
	   
    @RequestMapping(value = "/admin")
    public String adminManagement() 
    {
    	System.out.println("ADMIN CALLED.......");
    	return "adminHome";
    }
    
    @RequestMapping("/403")
    public String errorPage() 
    {
    	System.out.println("Error......");
    	return "403";
    }
    
    @RequestMapping(value = "/user")
    public String userManagement() 
    {
    	System.out.println("USER CALLED.......");
    	return "index";
    }
	
	

}
